<?php
$servername = "localhost"; // Your server name
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "booking"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all bookings from the bookings table
$query = "SELECT * FROM bookings";
$result = $conn->query($query);

// Error handling for query
if ($result === false) {
    die("Error with query: " . $conn->error); // Output error if query fails
} elseif ($result->num_rows === 0) {
    echo "No bookings found."; // Output message if no bookings are available
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Bookings</title>
    <link rel="stylesheet" href="admin/css/style.css"> <!-- Link to your CSS file -->
    <style>
        /* Main container styling */
        .main {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 16px;
            text-align: left;
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
        }

        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #28a745; /* Green header background */
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2; /* Alternate row color */
        }

        tr:hover {
            background-color: #e9e9e9; /* Row hover effect */
        }

        /* Header styling */
        h2 {
            text-align: center;
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
            text-transform: uppercase;
            font-weight: bold;
        }

        /* Responsive table */
        @media screen and (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
                width: 100%;
            }
            th {
                display: none;
            }
            tr {
                margin-bottom: 10px;
                box-shadow: 0 2px 3px rgba(0, 0, 0, 0.1);
            }
            td {
                display: block;
                padding: 10px;
                text-align: right;
                font-size: 14px;
                border-bottom: 1px solid #ddd;
                position: relative;
                padding-left: 50%;
            }
            td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: 45%;
                padding-left: 15px;
                font-weight: bold;
                text-align: left;
            }
        }
    </style>
</head>
<body>
    <div class="main">
        <h2>Current Bookings</h2>
        <table>
            <thead>
                <tr>
                   
                    <th>Username</th>
                    <th>Arrival</th>
                    <th>Destination</th>
                    <th>Time</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        
                        <td data-label="Username"><?php echo htmlspecialchars($row['username']); ?></td>
                        <td data-label="Arrival"><?php echo htmlspecialchars($row['arrival']); ?></td>
                        <td data-label="Destination"><?php echo htmlspecialchars($row['destination']); ?></td>
                        <td data-label="Time"><?php echo htmlspecialchars($row['time']); ?></td>
                        <td data-label="Date"><?php echo htmlspecialchars($row['date']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No bookings found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php $conn->close(); // Close the database connection ?>
