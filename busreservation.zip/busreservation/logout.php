<!DOCTYPE html>
<html lang="en">
<head>
    <title>Logout</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin/css/style.css"> <!-- Ensure your stylesheet path is correct -->
</head>
<body>
    <div class="logout-container">
        <h1>You have successfully logged out!</h1>
        <p>Thank you for using Bus Voyage. Click the button below to return to the home page.</p>
        <a href="index.php" class="btn">Return to Home</a>
    </div>
</body>
</html>
