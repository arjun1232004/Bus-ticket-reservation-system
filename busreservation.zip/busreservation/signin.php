<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "booking");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $uname = $_POST['uname']; // Get username from form
    $pword = $_POST['pword']; // Get password from form

    // Query to check if the user exists
    $query = "SELECT * FROM signup WHERE uname='$uname' AND pword='$pword'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Check if the account is approved
        if ($row['is_approved'] == 1) {
            $_SESSION['bus_owner'] = $row['uname']; // Store username in session
            header("Location: addbus.php"); // Redirect to manage buses page
            exit(); // Always exit after redirection
        } else {
            echo "<script>alert('Your account is not approved by the admin yet.');</script>";
        }
    } else {
        echo "<script>alert('Invalid username or password.');</script>"; // Invalid login details
    }
}

// Close the database connection
mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Form</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="signin/fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="signin/css/style.css">
</head>

<body>

    <div class="main">

        <!-- Login form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Login</h2>
                        
                        
                           
                                
                        <form method="POST" class="register-form" id="register-form">
                            <div class="form-group">
                                <label for="uname"><i class="zmdi zmdi-account"></i></label>
                                <input type="text" name="uname" id="uname" placeholder="Your Username" required/>
                            </div>
                            <div class="form-group">
                                <label for="pword"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pword" id="pword" placeholder="Password" required/>
                            </div>
                            
                            <div class="form-group form-button">
                                <input type="submit" name="submit" id="submit" class="form-submit" value="Login"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="signin/vendor/jquery/jquery.min.js"></script>
    <script src="signin/js/main.js"></script>
</body>
</html>
