<?php
$servername = "localhost";
$username = "root";
$password = ""; // Use your actual database password here
$dbname = "booking"; // Make sure this is the correct database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all bus owners except the admin
$query = "SELECT * FROM signup WHERE uname != 'Admin'"; // Exclude admin from the list
$result = $conn->query($query);

// Error handling for query
if ($result === false) {
    die("Error with query: " . $conn->error); // Output error if query fails
} elseif ($result->num_rows === 0) {
    echo "<div style='text-align:center;'>No bus owners found.</div>"; // Output message if no bus owners are available
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bus Owners</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Icons for buttons -->
    <style>
        /* Your CSS styles here */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            font-size: 24px;
            color: #343a40;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 14px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
            font-size: 16px;
        }
        th {
            background-color: #007bff;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .status-approved {
            color: green;
            font-weight: bold;
        }
        .status-unapproved {
            color: red;
            font-weight: bold;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 8px 16px;
            border-radius: 5px;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .approve-btn {
            background-color: #28a745;
            color: white;
            border: none;
        }
        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
        }
        .approve-btn:hover {
            background-color: #218838;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }
        .btn i {
            margin-right: 6px;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            table, th, td {
                font-size: 14px;
            }
            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="main">
        <h2>Registered Bus Owners</h2>
        <table>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Company Name</th>
                    <th>Ownership</th>
                    <th>License Number</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['company_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['ownership']); ?></td>
                        <td><?php echo htmlspecialchars($row['license_number']); ?></td>
                        <td><?php echo htmlspecialchars($row['ename']); ?></td>
                        <td>
                            <?php if ($row['is_approved']): ?>
                                <span class="status-approved">Approved</span>
                            <?php else: ?>
                                <span class="status-unapproved">Unapproved</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <?php if (!$row['is_approved']): ?>
                                    <a href="approve.php?uname=<?php echo urlencode($row['uname']); ?>" class="btn approve-btn">
                                        <i class="fas fa-check"></i> Approve
                                    </a>
                                <?php endif; ?>
                                <a href="delete.php?uname=<?php echo urlencode($row['uname']); ?>" class="btn delete-btn" onclick="return confirm('Are you sure you want to delete this bus owner?');">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align:center;">No bus owners found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php $conn->close(); ?>
