<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Access</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('hpage/img/background1.jpg'); /* Replace with your background image */
            background-size: cover;
            background-position: center;
            color: white; /* Make text white for contrast */
        }

        .container {
            max-width: 400px;
            margin: auto;
            padding: 30px;
            background: rgba(0, 0, 0, 0.7); /* Dark overlay for better text visibility */
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        h2 {
            color: #ffcc00; /* Highlighted text color */
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 15px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            margin: 10px 0;
            transition: background-color 0.3s, transform 0.2s;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
        }

        .btn:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        /* Responsive Design */
        @media (max-width: 500px) {
            .container {
                width: 90%; /* Make container responsive */
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Access</h2>
        <a href="login.php" class="btn">Login</a>
    </div>
</body>
</html>
