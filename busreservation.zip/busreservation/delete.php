<?php

$servername = "localhost";
$username = "root";
$password = ""; // Use your actual database password here
$dbname = "booking"; // Make sure this is the correct database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_GET['uname'])) {
    $uname = $_GET['uname'];

    // Prepare and execute the delete query
    $stmt = $conn->prepare("DELETE FROM signup WHERE uname = ?");
    $stmt->bind_param("s", $uname);

    if ($stmt->execute()) {
        echo "<script>alert('Bus owner deleted successfully!'); window.location.href='manageowners.php';</script>";
    } else {
        echo "<script>alert('Error deleting bus owner: " . $stmt->error . "'); window.location.href='manageowners.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('No bus owner specified to delete.'); window.location.href='manageowners.php';</script>";
}

$conn->close(); // Close the database connection
?>
