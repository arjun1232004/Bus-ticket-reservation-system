<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Payment Form</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" type="text/css" href="pay/css/nunito-font.css">
    <link rel="stylesheet" href="pay/css/style.css"/>
</head>
<body class="form-v9">
    <div class="page-content">
        <div class="form-v9-content" style="background-image: url('pay/images/form-v9.jpg')">
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "booking";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $alertMessage = '';

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $fullName = htmlspecialchars($_POST['full-name']);
                $email = htmlspecialchars($_POST['your-email']);
                $seatNumber = htmlspecialchars($_POST['seatnumber']);
                $busId = htmlspecialchars($_POST['bus_id']);
                $cardNumber = htmlspecialchars($_POST['card-number']);
                $expirationDate = htmlspecialchars($_POST['expiration-date']);
                $cvv = htmlspecialchars($_POST['cvv']);

                $transactionStatus = 'Completed'; 
                $sql = "INSERT INTO payments (full_name, email, seat_number, bus_id, card_number, expiration_date, cvv, transaction_status)
                        VALUES ('$fullName', '$email', '$seatNumber', '$busId', '$cardNumber', '$expirationDate', '$cvv', '$transactionStatus')";

                if ($conn->query($sql) === TRUE) {
                    // Set alert message
                    $alertMessage = "Your seats have been booked!";
                    // Redirect to profile page
                    echo "<script>
                            alert('$alertMessage');
                            window.location.href = 'profile.php';
                          </script>";
                    exit; // Stop executing the rest of the script
                } else {
                    $alertMessage = "Error processing payment: " . $conn->error;
                }
            }
            ?>

            <form class="form-detail" method="post" action="">
                <h2>Payment Form</h2>
                <input type="hidden" name="seatnumber" value="<?php echo isset($_GET['seatnumber']) ? htmlspecialchars($_GET['seatnumber']) : ''; ?>">
                <input type="hidden" name="bus_id" value="<?php echo isset($_GET['bus_id']) ? htmlspecialchars($_GET['bus_id']) : ''; ?>">

                <div class="form-row-total">
                    <div class="form-row">
                        <input type="text" name="full-name" class="input-text" placeholder="Your Name" required>
                    </div>
                    <div class="form-row">
                        <input type="email" name="your-email" class="input-text" placeholder="Your Email" required>
                    </div>
                </div>
                <div class="form-row-total">
                    <div class="form-row">
                        <input type="text" name="card-number" class="input-text" placeholder="Credit Card Number" required>
                    </div>
                    <div class="form-row">
                        <input type="text" name="expiration-date" class="input-text" placeholder="MM/YY" required>
                    </div>
                </div>
                <div class="form-row-total">
                    <div class="form-row">
                        <input type="password" name="cvv" class="input-text" placeholder="CVV" required>
                    </div>
                    <div class="form-row">
                        <input type="password" name="password" class="input-text" placeholder="Password" required>
                    </div>
                </div>
                <div class="form-row-last">
                    <input type="submit" name="pay" class="register" value="Pay">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
