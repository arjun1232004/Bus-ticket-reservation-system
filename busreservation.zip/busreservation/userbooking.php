<?php
session_start(); // Start session to access logged-in user details

$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "booking"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    die("Please log in to view your bookings.");
}

$loggedInUser = $_SESSION['username']; // Get the logged-in user's username

// Cancel booking if requested
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking_id'])) {
    $cancelBookingId = intval($_POST['cancel_booking_id']);
    $cancelQuery = "DELETE FROM bookings WHERE id = ? AND username = ?";
    $stmt = $conn->prepare($cancelQuery);
    $stmt->bind_param("is", $cancelBookingId, $loggedInUser);
    $stmt->execute();
    $stmt->close();
}

// Fetch bookings for the logged-in user
$query = "SELECT id, arrival, destination, time, date FROM bookings WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $loggedInUser);
$stmt->execute();
$result = $stmt->get_result();

// Fetch seat details for each booking
$seats = [];
if ($result && $result->num_rows > 0) {
    while ($booking = $result->fetch_assoc()) {
        // Fetch seats for this particular booking
        $seatQuery = "SELECT seatnumber FROM seats WHERE seatid = ?";
        $seatStmt = $conn->prepare($seatQuery);

        if ($seatStmt === false) {
            die("Error preparing query: " . $conn->error);
        }

        $seatStmt->bind_param("i", $booking['id']);
        $seatStmt->execute();
        $seatResult = $seatStmt->get_result();

        // Store seat numbers for the current booking
        $seatNumbers = [];
        while ($seat = $seatResult->fetch_assoc()) {
            $seatNumbers[] = $seat['seatnumber'];
        }
        
        // Add seat numbers to the booking details
        $booking['seats'] = $seatNumbers;
        
        // Add the booking (with seat numbers) to the array
        $seats[] = $booking;
        
        $seatStmt->close();
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Digital Tickets</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 10px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .ticket {
            background: linear-gradient(135deg, #ff9a9e, #fad0c4);
            margin: 10px;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            width: 280px;
            text-align: center;
            position: relative;
            transition: transform 0.3s ease;
        }
        .ticket:hover {
            transform: translateY(-10px);
        }
        .ticket h3 {
            margin: 10px 0;
            color: #2c3e50;
            font-weight: 700;
        }
        .ticket p {
            margin: 5px 0;
            color: #34495e;
            font-weight: 500;
        }
        .ticket .seats {
            font-weight: bold;
            margin: 10px 0;
            color: #27ae60;
        }
        .ticket button {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .ticket button:hover {
            background-color: #c0392b;
        }
        .no-bookings {
            text-align: center;
            color: #7f8c8d;
            font-size: 18px;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (count($seats) > 0): ?>
            <?php foreach ($seats as $booking): ?>
                <div class="ticket">
                    <h3>Your Ticket</h3>
                    <p><strong>From:</strong> <?php echo htmlspecialchars($booking['arrival']); ?></p>
                    <p><strong>To:</strong> <?php echo htmlspecialchars($booking['destination']); ?></p>
                    <p><strong>Time:</strong> <?php echo htmlspecialchars($booking['time']); ?></p>
                    <p><strong>Date:</strong> <?php echo htmlspecialchars($booking['date']); ?></p>
                    <p class="seats">Seat Number(s): <?php echo implode(', ', $booking['seats']); ?></p>
                    <form method="post">
                        <input type="hidden" name="cancel_booking_id" value="<?php echo $booking['id']; ?>">
                        <button type="submit">Cancel</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-bookings">You have no bookings.</p>
        <?php endif; ?>
    </div>
</body>
</html>
