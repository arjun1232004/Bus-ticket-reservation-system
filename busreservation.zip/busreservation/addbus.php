<?php
session_start(); // Start the session to access session variables

// Database connection
$conn = mysqli_connect("localhost", "root", "", "booking");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch routes for bus owners
$routes_result = $conn->query("SELECT * FROM routes");

// Variable to hold the price for the selected route
$route_price = 0;

// Adding a new bus
if (isset($_POST['add_bus'])) {
    $route_id = $_POST['route_id']; // Route selected from the dropdown
    $bus_name = $_POST['bus_name']; // New field for bus name
    $bus_number = $_POST['bus_number'];
    $capacity = $_POST['capacity'];
    $owner_name = $_POST['bus_owner']; // Get bus owner's name from the input
    $driver_name = $_POST['driver_name']; // New field for driver name
    $driver_contact = $_POST['driver_contact']; // New field for driver contact
    $conductor_name = $_POST['conductor_name']; // New field for conductor name
    $conductor_contact = $_POST['conductor_contact']; // New field for conductor contact

    // Prepare and execute the insert query
    $query = "INSERT INTO buses (route_id, bus_name, bus_number, capacity, bus_owner, driver_name, driver_contact, conductor_name, conductor_contact) 
              VALUES ('$route_id', '$bus_name', '$bus_number', '$capacity', '$owner_name', '$driver_name', '$driver_contact', '$conductor_name', '$conductor_contact')";
    if (mysqli_query($conn, $query)) {
        echo "Bus added successfully!";
    } else {
        echo "Error adding bus: " . mysqli_error($conn);
    }
}

// Example of setting the bus owner's name (e.g., from a session)
$owner_name = isset($_SESSION['bus_owner_name']) ? $_SESSION['bus_owner_name'] : ''; // Use the actual key you set in the session

// Check if a route is selected to get the corresponding price
if (isset($_POST['route_id'])) {
    $route_id = $_POST['route_id'];
    $price_query = "SELECT price FROM routes WHERE route_id = '$route_id'";
    $price_result = $conn->query($price_query);
    if ($price_result && $price_result->num_rows > 0) {
        $price_row = $price_result->fetch_assoc();
        $route_price = $price_row['price'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Bus</title>
    <link rel="stylesheet" href="admin/css/style.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .main {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            margin-top: 0;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="text"],
        input[type="number"],
        select {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .price {
            font-weight: bold;
            margin-top: 10px;
            color: #e74c3c;
        }
    </style>
</head>
<body>
    <div class="main">
        <h2>Add a New Bus</h2>
        <form method="post">
            <label>Select Route:</label>
            <select name="route_id" required onchange="this.form.submit()">
                <?php 
                // Check if routes exist
                if ($routes_result && $routes_result->num_rows > 0) {
                    while ($route = $routes_result->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($route['route_id']); ?>" <?php echo (isset($route_id) && $route_id == $route['route_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($route['start_point'] . " - " . $route['end_point']); ?>
                        </option>
                    <?php endwhile;
                } else {
                    echo "<option value=''>No routes available</option>";
                }
                ?>
            </select><br>

            <div class="price">Price: ₹<?php echo $route_price; ?></div>

            <label>Bus Name:</label>
            <input type="text" name="bus_name" required><br> <!-- New field for bus name -->

            <label>Bus Number:</label>
            <input type="text" name="bus_number" required><br>
            
            <label>Capacity:</label>
            <input type="number" name="capacity" required><br>
            
            <label>Bus Owner Name:</label>
            <input type="text" name="bus_owner" value="<?php echo htmlspecialchars($owner_name); ?>" required><br>
            <h3>Crew Details</h3>
            <label>Driver Name:</label>
            <input type="text" name="driver_name" required><br> <!-- New field for driver name -->

            <label>Driver Contact:</label>
            <input type="text" name="driver_contact" required><br> <!-- New field for driver contact -->

            <label>Conductor Name:</label>
            <input type="text" name="conductor_name" required><br> <!-- New field for conductor name -->

            <label>Conductor Contact:</label>
            <input type="text" name="conductor_contact" required><br> <!-- New field for conductor contact -->

            <button type="submit" name="add_bus">Add Bus</button>
        </form>
    </div>
</body>
</html>

<?php $conn->close(); ?>
