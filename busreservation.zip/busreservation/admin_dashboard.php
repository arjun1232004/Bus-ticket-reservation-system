<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bus Booking Admin Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin/css/style.css"> <!-- Link to your CSS file -->
    <style>
        /* Add your CSS styles here */
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
            display: flex;
            background-color: #f4f6f8; /* Light background for better contrast */
        }

        .sidebar {
            width: 250px;
            background-color: #34495e; /* Darker sidebar color */
            color: white;
            padding: 20px;
            height: 100vh;
            position: fixed;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.2); /* Shadow for depth */
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 24px;
            font-weight: bold;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px 15px;
            text-decoration: none;
            margin: 10px 0;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #1abc9c; /* Changed hover color */
        }

        .main {
            margin-left: 250px; /* Offset for the sidebar */
            padding: 20px;
            flex: 1;
            background-color: #ecf0f1;
        }

        .header {
            background-color: #2980b9; /* Primary header color */
            color: white;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .card {
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
            transition: transform 0.2s; /* Animation effect */
        }

        .card:hover {
            transform: scale(1.03); /* Slightly enlarge on hover */
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }
            .main {
                margin-left: 200px;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                position: relative;
                height: auto;
            }
            .main {
                margin-left: 0;
            }
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <a href="manageowners.php">Manage Bus owner</a>
        <a href="view-bookings.php">View Bookings</a>
        <a href="manageroute.php">Add route</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main">
        <div class="header">
            <h1>Welcome to the Bus Booking Admin Dashboard!</h1>
        </div>
        <div class="card">
            <h2>Manage bus owner</h2>
            <p>See all current and past bookings.</p>
            <a href="manageowners.php">Manage Bus owner</a>
        
        
        <div class="card">
            <h2>View Bookings</h2>
            <p>See all current and past bookings.</p>
            <a href="view-bookings.php">Go to View Bookings</a>
        </div>
        
        <div class="card">
            <h2>Add route </h2>
            <p>Add routes for owners.</p>
            <a href="manageroute.php">Go to Add route</a>
        </div>
        <div class="card">
            <h2>manage bus </h2>
            <a href="managebus.php">Go to buses</a>
        </div>
    </div>
</body>
</html>
