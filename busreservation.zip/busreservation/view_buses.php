<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bus Voyage - View Buses</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homep/css/style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f3f5;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #2980b9;
            margin-bottom: 30px;
            font-size: 2.5em;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .bus-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            transition: transform 0.3s;
        }
        .bus-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }
        .bus-card h2 {
            font-size: 1.5em;
            color: #2980b9;
            margin-bottom: 10px;
        }
        .bus-card p {
            margin: 5px 0;
            color: #555;
        }
        .btn {
            display: block;
            text-align: center;
            padding: 10px 15px;
            color: white;
            background-color: #e74c3c;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s;
            margin-top: 10px;
        }
        .btn:hover {
            background-color: #c0392b;
        }
        footer {
            text-align: center;
            margin-top: 40px;
            font-size: 0.9em;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <h1>Available Buses</h1>
    <div class="container">
        <?php
        // Database connection
        $conn = mysqli_connect("localhost", "root", "", "booking");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Query to fetch buses with their associated routes, prices, and calculate available capacity
        $query = "
            SELECT buses.bus_id, buses.bus_name, buses.bus_number, buses.capacity, routes.start_point, routes.end_point, routes.price,
            (buses.capacity - COALESCE((SELECT COUNT(*) FROM seats WHERE bus_id = buses.bus_id AND status='booked'), 0)) AS available_capacity
            FROM buses 
            JOIN routes ON buses.route_id = routes.route_id";

        $result = $conn->query($query);

        // Check if query executed successfully
        if (!$result) {
            // Output the error if the query fails
            echo "Error executing query: " . $conn->error;
        } elseif ($result->num_rows > 0) {
            // Output data of each bus in a card layout
            while ($row = $result->fetch_assoc()) {
                echo "<div class='bus-card'>
                        <h2>" . htmlspecialchars($row["bus_name"]) . "</h2>
                        <p><strong>Bus Number:</strong> " . htmlspecialchars($row["bus_number"]) . "</p>
                        <p><strong>Capacity:</strong> " . htmlspecialchars($row["capacity"]) . "</p>
                        <p><strong>Available Capacity:</strong> " . htmlspecialchars($row["available_capacity"]) . "</p>
                        <p><strong>Route:</strong> " . htmlspecialchars($row["start_point"] . " - " . $row["end_point"]) . "</p>
                        <p><strong>Price:</strong> ₹" . htmlspecialchars($row["price"]) . "</p> <!-- Displaying price -->
                        <a href='select_seat.php?bus_id=" . htmlspecialchars($row["bus_id"]) . "' class='btn'>Select Seats</a>
                      </div>";
            }
        } else {
            // Display if no buses are available
            echo "<p>No buses available.</p>";
        }

        // Close the connection
        $conn->close();
        ?>
    </div>

    <a href="index.php" class="btn">Back to Home</a>

    <footer>
        &copy; 2024 Bus Voyage. All rights reserved.
    </footer>
</body>
</html>
