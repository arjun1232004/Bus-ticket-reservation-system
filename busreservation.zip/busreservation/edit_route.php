<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "booking");

// Check if the route ID is set in the URL
if (isset($_GET['id'])) {
    $route_id = $_GET['id'];

    // Retrieve the route data based on the route ID
    $query = $conn->prepare("SELECT * FROM routes WHERE route_id = ?");
    $query->bind_param("i", $route_id);
    $query->execute();
    $result = $query->get_result();
    $route = $result->fetch_assoc();

    if (!$route) {
        echo "Route not found!";
        exit;
    }
} else {
    echo "No route ID specified!";
    exit;
}

// Update the route data if the form is submitted
if (isset($_POST['update_route'])) {
    $start = $_POST['start_point'];
    $end = $_POST['end_point'];
    $price = $_POST['price'];
    $time = $_POST['time'];

    $update_query = $conn->prepare("UPDATE routes SET start_point = ?, end_point = ?, price = ?, time = ? WHERE route_id = ?");
    $update_query->bind_param("ssdsi", $start, $end, $price, $time, $route_id);

    if ($update_query->execute()) {
        echo "Route updated successfully!";
        header("Location: manageroute.php"); // Redirect back to the routes management page
        exit;
    } else {
        echo "Error updating route: " . $update_query->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Route</title>
    <link rel="stylesheet" href="admin/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .main {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="text"], input[type="submit"] {
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
<div class="main">
    <h2>Edit Route</h2>
    <form method="POST">
        <label>Start Point:</label>
        <input type="text" name="start_point" value="<?php echo $route['start_point']; ?>" required>

        <label>End Point:</label>
        <input type="text" name="end_point" value="<?php echo $route['end_point']; ?>" required>

        <label>Price:</label>
        <input type="text" name="price" value="<?php echo $route['price']; ?>" required>

        <label>Time:</label>
        <input type="text" name="time" value="<?php echo $route['time']; ?>" required>

        <input type="submit" name="update_route" value="Update Route">
    </form>
</div>

</body>
</html>

<?php $conn->close(); ?>
