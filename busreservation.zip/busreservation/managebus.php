

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bus</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .main {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
            font-size: 24px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
            text-transform: uppercase;
        }
        .action-buttons a {
            padding: 5px 10px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }
        .delete-btn {
            background-color: #dc3545;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "booking");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch all buses
$query = "SELECT bus_number, bus_owner, bus_name, bus_id FROM buses";
$result = mysqli_query($conn, $query);

// Handle query error or empty result set
if (!$result) {
    die("Query error: " . mysqli_error($conn));
}
?>
<body>
    <div class="main">
        <h2>Registered Bus Owners</h2>
        <table>
            <thead>
                <tr>
                    <th>Bus Number</th>
                    <th>Bus Owner</th>
                    <th>Bus Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $row['bus_number']; ?></td>
                            <td><?php echo $row['bus_owner']; ?></td>
                            <td><?php echo $row['bus_name']; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="delete.php?bus_id=<?php echo $row['bus_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this bus?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">No buses found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
