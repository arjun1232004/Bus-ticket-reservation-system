<?php
$servername = "localhost";
$username = "root";
$password = ""; // Use your actual database password here
$dbname = "booking"; // Make sure this is the correct database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username from the URL
$uname = isset($_GET['uname']) ? $_GET['uname'] : '';

if ($uname) {
    // Update the bus owner to mark them as approved
    $query = "UPDATE signup SET is_approved = TRUE WHERE uname = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $uname);

    if ($stmt->execute()) {
        echo "Bus owner approved successfully.";
        header("Location: manageowners.php"); // Redirect back to the manage owners page
        exit;
    } else {
        echo "Error approving bus owner: " . $conn->error;
    }
} else {
    echo "No bus owner specified.";
}

$conn->close();
?>
