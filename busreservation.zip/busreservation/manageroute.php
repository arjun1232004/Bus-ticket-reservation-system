<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "booking");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Adding a new route
if (isset($_POST['add_route'])) {
    $start = $_POST['start_point'];
    $end = $_POST['end_point'];
    $price = $_POST['price'];
    $time = $_POST['time'];

    // Basic query to add route
    $query = "INSERT INTO routes (start_point, end_point, price, time) VALUES ('$start', '$end', '$price', '$time')";
    if (mysqli_query($conn, $query)) {
        echo "Route added successfully!";
    } else {
        echo "Error adding route: " . mysqli_error($conn);
    }
}

// Fetch routes to display in the table
$routes_result = mysqli_query($conn, "SELECT * FROM routes");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Routes</title>
    <link rel="stylesheet" href="admin/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .main {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            margin-top: 0;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
        }
        input[type="text"], input[type="submit"] {
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .edit-button {
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            text-decoration: none;
        }
        .edit-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="main">
        <h2>Add a New Route</h2>
        <form method="POST">
            <label>Start Point:</label>
            <input type="text" name="start_point" required>

            <label>End Point:</label>
            <input type="text" name="end_point" required>

            <label>Price:</label>
            <input type="text" name="price" required>

            <label>Time:</label>
            <input type="text" name="time" required>

            <input type="submit" name="add_route" value="Add Route">
        </form>

        <h2>Existing Routes</h2>
        <table>
            <tr>
                <th>Start Point</th>
                <th>End Point</th>
                <th>Price</th>
                <th>Time</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($routes_result)): ?>
                <tr>
                    <td><?php echo $row['start_point']; ?></td>
                    <td><?php echo $row['end_point']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <td><?php echo $row['time']; ?></td>
                    <td>
                        <a href="edit_route.php?id=<?php echo $row['route_id']; ?>" class="edit-button">Edit</a>
                        <a href="deleteroute.php?route_id=<?php echo $row['route_id']; ?>" class="edit-button" style="background-color: #d9534f;">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>

<?php $conn->close(); ?>
