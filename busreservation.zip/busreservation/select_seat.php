<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Your Seat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .bus {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 20px;
        }
        .bus-row {
            display: flex;
            justify-content: center;
            margin: 5px 0;
        }
        .seat {
            width: 40px;
            height: 40px;
            margin: 5px;
            background-color: #1abc9c;
            text-align: center;
            line-height: 40px;
            color: white;
            border: none;
            cursor: pointer;
        }
        .seat.booked {
            background-color: #e74c3c;
            cursor: not-allowed;
        }
        .seat.selected {
            background-color: #3498db;
        }
        .aisle {
            width: 20px;
        }
    </style>
</head>
<body>

<?php
$conn = mysqli_connect("localhost", "root", "", "booking");

$bus_id = isset($_GET['bus_id']) ? intval($_GET['bus_id']) : 0;
$bookedSeats = [];

// Fetching booked seats for the specified bus ID
$result = mysqli_query($conn, "SELECT seatnumber FROM seats WHERE bus_id = $bus_id AND status = 'booked'");
while ($row = mysqli_fetch_assoc($result)) {
    $bookedSeats[] = $row['seatnumber'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $seatnumber = $_POST['seatnumber'];

    // Insert booking if seat is not already booked
    $checkSeat = mysqli_query($conn, "SELECT * FROM seats WHERE seatnumber = '$seatnumber' AND bus_id = $bus_id");
    if (mysqli_num_rows($checkSeat) == 0) {
        mysqli_query($conn, "INSERT INTO seats (seatnumber, status, bus_id) VALUES ('$seatnumber', 'booked', $bus_id)");
        header("Location: payment.php?seatnumber=$seatnumber&bus_id=$bus_id");
        exit();
    } else {
        echo "<script>alert('Seat $seatnumber is already booked. Please select another.');</script>";
    }
}

mysqli_close($conn);
?>

<div class="bus">
    <h2>Select Your Seat</h2>
    <form method="post">
        <?php for ($row = 1; $row <= 10; $row++): ?>
            <div class="bus-row">
                <?php for ($seat = 1; $seat <= 5; $seat++): ?>
                    <?php 
                    $seatNumber = ($row - 1) * 5 + $seat; 
                    $isBooked = in_array($seatNumber, $bookedSeats) ? ' booked' : ''; 
                    ?>
                    <button type="button" class="seat<?= $isBooked ?>" 
                        <?= $isBooked ? 'disabled' : 'onclick="selectSeat(this, \'' . $seatNumber . '\')"' ?>>
                        <?= $seatNumber ?>
                    </button>
                    <?php if ($seat == 2 || $seat == 3): ?>
                        <div class="aisle"></div>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
        <?php endfor; ?>

        <input type="hidden" id="seatnumber" name="seatnumber">
        <button type="submit">Pay</button>
    </form>
</div>

<script>
    function selectSeat(button, seatNumber) {
        document.querySelectorAll('.seat').forEach(seat => seat.classList.remove('selected'));
        button.classList.add('selected');
        document.getElementById('seatnumber').value = seatNumber;
    }
</script>
</body>
</html>
