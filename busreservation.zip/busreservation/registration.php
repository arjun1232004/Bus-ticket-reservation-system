<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form</title>
    <link rel="stylesheet" href="register/fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="register/css/style.css">
</head>
<?php
$conn = mysqli_connect("localhost", "root", "", "booking");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $firstName = $_POST["first_name"];
    $lastName = $_POST["last_name"];
    $ownership = $_POST["ownership"];
    $licenseNo = $ownership == 'Yes' ? $_POST["license_number"] : ''; 
    $companyName = $_POST["company_name"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $phone = $_POST["phoneno"];  // New phone field
    $password = $_POST["password"];

    $sql = "INSERT INTO signup (first_name, last_name, ownership, license_number, company_name, uname, ename, phoneno, pword, is_approved) 
            VALUES ('$firstName', '$lastName', '$ownership', '$licenseNo', '$companyName', '$username', '$email', '$phone', '$password', 0)";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Registration successful! Please wait for admin approval.');</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}

mysqli_close($conn);
?>
<body>

    <div class="main">
        <div class="container">
            <div class="signup-content">
                <div class="signup-img">
                    <img src="register/images/img.jpg" alt="">
                </div>
                <div class="signup-form">
                    <form method="POST" class="register-form" id="register-form">
                        <h2>Registration Form</h2>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">First Name :</label>
                                <input type="text" name="first_name" id="first_name" required/>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name :</label>
                                <input type="text" name="last_name" id="last_name" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="company_name">Company Name :</label>
                            <input type="text" name="company_name" id="company_name" required/>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number :</label> 
                            <input type="text" name="phoneno" id="phone" required/>
                        </div>
                        <div class="form-radio">
                            <label for="ownership" class="radio-label">Do you have bus ownership:</label>
                            <div class="form-radio-item">
                                <input type="radio" name="ownership" id="ownership_yes" value="Yes" required>
                                <label for="ownership_yes">Yes</label>
                                <span class="check"></span>
                            </div>
                            <div class="form-radio-item">
                                <input type="radio" name="ownership" id="ownership_no" value="No">
                                <label for="ownership_no">No</label>
                                <span class="check"></span>
                            </div>
                        </div>
                        <div class="form-group" id="license_number_div" style="display:none;">
                            <label for="license_number">License Number :</label>
                            <input type="text" name="license_number" id="license_number"/>
                        </div>
                        <div class="form-group">
                            <label for="email">Email ID :</label>
                            <input type="email" name="email" id="email" required />
                        </div>
                        <div class="form-group">
                            <label for="username">Username :</label>
                            <input type="text" name="username" id="username" required />
                        </div>
                        <div class="form-group">
                            <label for="password">Password :</label>
                            <input type="password" name="password" id="password" required />
                        </div>
                        <div class="form-submit">
                            <input type="submit" value="Reset All" class="submit" name="reset" id="reset" />
                            <input type="submit" value="Submit Form" class="submit" name="submit" id="submit" />
                            <a href="signin.php" class="btn">login</a>                       
                         </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="register/vendor/jquery/jquery.min.js"></script>
    <script src="register/js/main.js"></script>
    
    <script>
        document.querySelectorAll('input[name="ownership"]').forEach((elem) => {
            elem.addEventListener("change", function(event) {
                const licenseNumberDiv = document.getElementById('license_number_div');
                if (event.target.value === "Yes") {
                    licenseNumberDiv.style.display = "block";
                } else {
                    licenseNumberDiv.style.display = "none";
                }
            });
        });
    </script>
</body>
</html>
