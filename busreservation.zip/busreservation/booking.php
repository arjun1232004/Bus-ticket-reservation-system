<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bus Voyage - Booking Form</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no" />
    <link rel="stylesheet" href="homep/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-KyZXEAg3QhqLMpG8r+Knujsl5+wH9Sj6B1QYoP6DF1Bb8dd0MVP6F6k6WpbOV3ZPiVoG7zU9TAWZ7zV2h5pYQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Full-screen background image */
        body {
            background-image: url('hpage/img/booking.jpg'); /* Replace with the path to your image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            color: #333;
            display: flex; /* Flexbox for centering */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
        }

        .form_wrapper {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px; /* Reduced padding */
            border-radius: 20px; /* Rounded corners */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5); /* Soft shadow */
            width: 90%;
            max-width: 800px; /* Increased max width for two-column layout */
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white */
            backdrop-filter: blur(10px); /* Blur effect for background */
            position: relative;
        }

        h3 {
            margin-bottom: 15px; /* Reduced margin */
            color: #28a745; /* Bus Voyage green */
            text-align: center;
            font-size: 24px; /* Reduced font size for heading */
            font-weight: bold; /* Bold heading */
        }

        .form-container {
            display: flex; /* Flexbox for left-right layout */
            justify-content: space-between;
            width: 100%;
        }

        .form-section {
            width: 48%; /* Set width to slightly less than half */
        }

        .input-container {
            position: relative;
            width: 100%;
            margin: 10px 0; /* Reduced margin for spacing */
        }

        input,
        select {
            width: 100%;
            padding: 10px 10px; /* Slightly reduced padding */
            margin: 5px 0;
            border-radius: 10px; /* More rounded edges */
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
            transition: all 0.3s ease;
            border-bottom: 2px solid #28a745; /* Bottom border for focus effect */
            outline: none;
        }

        input:focus,
        select:focus {
            border-color: #28a745; /* Highlight border on focus */
            box-shadow: 0 0 5px rgba(40, 167, 69, 0.5); /* Shadow on focus */
        }

        .floating-label {
            position: absolute;
            left: 10px;
            top: 12px;
            font-size: 16px;
            color: #aaa;
            transition: all 0.2s ease;
            pointer-events: none;
        }

        input:focus + .floating-label,
        input:not(:placeholder-shown) + .floating-label {
            top: -10px;
            left: 10px;
            font-size: 12px;
            color: #28a745; /* Change color on focus */
        }

        .button-container {
            display: flex;
            justify-content: space-between; /* Space out the buttons */
            width: 100%; /* Full width for button container */
            margin-top: 15px; /* Reduced spacing above the button container */
        }

        .btn {
            display: inline-block;
            padding: 10px 20px; /* Reduced button padding */
            color: white;
            background-color: #007bff; /* Blue color for buttons */
            border-radius: 10px; /* More rounded edges */
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.2s;
            border: none;
            cursor: pointer;
            font-size: 16px;
            box-shadow: 0 4px 8px rgba(0, 123, 255, 0.2);
            flex: 1; /* Equal button width */
            margin: 0 5px; /* Space between buttons */
        }

        .btn:hover {
            background-color: #0056b3; /* Darker blue on hover */
            transform: translateY(-2px); /* Lift effect */
        }

        .btn:active {
            transform: translateY(0); /* Reset on click */
        }

        /* Progress Bar */
        .progress-container {
            width: 100%;
            background-color: #ddd;
            border-radius: 5px;
            margin-bottom: 15px; /* Reduced margin */
            height: 10px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background-color: #28a745;
            width: 0%; /* Initial width */
            transition: width 0.5s;
        }

        /* Tooltip Styling */
        .tooltip {
            display: inline-block;
            position: relative;
        }

        .tooltip:hover::after {
            content: attr(data-tooltip);
            position: absolute;
            left: 50%;
            bottom: 125%; /* Position above the input */
            transform: translateX(-50%);
            background-color: #333;
            color: #fff;
            padding: 5px;
            border-radius: 5px;
            white-space: nowrap;
            z-index: 10;
            font-size: 12px;
            opacity: 0.8;
        }
       
        @media (max-width: 600px) {
            .form_wrapper {
                padding: 15px; /* Further reduce padding */
            }

            h3 {
                font-size: 22px; /* Smaller heading font size */
            }

            .btn {
                padding: 8px 16px; /* Smaller button padding */
            }

            .form-section {
                width: 100%; /* Stack sections on small screens */
                margin-bottom: 20px; /* Space between stacked sections */
            }
        }
    </style>
</head>


<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "booking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = $_POST['fullname'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $n = $_POST['username'];
    $e = $_POST['arrival'];
    $p = $_POST['destination'];
    $t = $_POST['time'];
    $d = $_POST['date'];
    $password=$_POST['password'];
    $submitType = $_POST['submit'];  // Get which button was clicked

    // Insert data into the bookings table
    $sql = "INSERT INTO bookings (username, arrival, destination, time, date, fullname, address, contact, email,password) 
            VALUES ('$n', '$e', '$p', '$t', '$d', '$fullname', '$address', '$contact', '$email','$password')";

    // Check if the query was successful
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Success');</script>";
        
        // Redirect based on which button was clicked
        if ($submitType == 'view_buses') {
            echo "<script>window.location.href = 'view_buses.php';</script>";
        } else {
            echo "<script>window.location.href = 'index.php';</script>";
        }
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Close the connection
$conn->close();
?>
<body>

    <div class="form_wrapper">
        <h3><i class="fas fa-bus"></i> Bus Booking Form</h3>
       
        <!-- Progress Bar -->
        <div class="progress-container">
            <div class="progress-bar" style="width: 100%;"></div>
        </div>

        <form id="bookingForm" method="POST">
            <div class="form-container">
                <div class="form-section">
                    <div class="input-container tooltip">
                        <input name="fullname" placeholder=" " required>
                        <label class="floating-label">Full Name</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="address" placeholder=" " required>
                        <label class="floating-label">Address</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="contact" placeholder=" " required>
                        <label class="floating-label">Contact Number</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="email" type="email" placeholder=" " required>
                        <label class="floating-label">Email ID</label>
                    </div>
                </div>
                <div class="form-section">
                    <div class="input-container tooltip">
                        <input name="arrival" placeholder=" " required>
                        <label class="floating-label">From</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="destination" placeholder=" " required>
                        <label class="floating-label">To</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="time" type="time" placeholder=" " required>
                        <label class="floating-label">Time</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="date" type="date" placeholder=" " required>
                        <label class="floating-label">Date</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="username" placeholder=" " required>
                        <label class="floating-label">Username</label>
                    </div>
                    <div class="input-container tooltip">
                        <input name="username" type="password" placeholder=" " required>
                        <label class="floating-label">password</label>
                    </div>
                </div>
            </div>
            

            <div class="button-container">
                <button type="submit" name="submit" value="view_buses" class="btn">View Buses</button>
                <a href="index.php" class="btn">home</a>
            </div>
        </form>
    </div>
</body>

</html>
