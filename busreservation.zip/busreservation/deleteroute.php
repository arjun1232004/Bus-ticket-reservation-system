<?php

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "booking"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['route_id'])) {
    $route_id = $_GET['route_id'];

    
    $stmt = $conn->prepare("DELETE FROM routes WHERE route_id = ?");
    $stmt->bind_param("i", $route_id);
    $stmt->execute();

    echo "<script>alert('Route deleted successfully!'); window.location.href='manageroute.php';</script>";

    $stmt->close();
} else {
    echo "<script>alert('No route specified to delete.'); window.location.href='manageroute.php';</script>";
}

$conn->close();
?>
