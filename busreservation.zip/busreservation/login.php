<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('hpage/img/login-background.jpg'); /* Different background image */
            background-size: cover;
            background-position: center;
            color: #ffffff; /* White text color for contrast */
        }

        .container {
            max-width: 400px;
            padding: 30px;
            background: rgba(0, 0, 0, 0.9); /* Darker overlay for more contrast */
            border-radius: 15px; /* More rounded corners */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7); /* Stronger shadow for depth */
        }

        h2 {
            color: #ffcc00; /* Bright yellow color for emphasis */
            margin-bottom: 20px;
            text-align: center; /* Center align heading */
        }

        input {
            width: 100%;
            padding: 12px; /* Increased padding for input fields */
            margin: 10px 0;
            border-radius: 10px; /* Rounded input fields */
            border: 2px solid #ccc; /* Thicker border */
            box-sizing: border-box;
            transition: border-color 0.3s; /* Smooth transition for input */
        }

        input:focus {
            border-color: #ffcc00; /* Highlight border on focus */
            outline: none; /* Remove default outline */
        }

        .btn {
            display: inline-block;
            padding: 15px 20px;
            background-color: #007bff; /* Changed button color to blue */
            color: white;
            border: none;
            border-radius: 10px; /* Matching rounded corners */
            text-decoration: none;
            margin: 10px 0;
            transition: background-color 0.3s, transform 0.2s;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
        }

        .btn:hover {
            background-color: #0056b3; /* Darker blue on hover */
            transform: translateY(-2px); /* Slight lift on hover */
        }

        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: #ccc; /* Subtle footer text color */
        }
    </style>
</head>
<?php
    session_start();
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection
        $conn = mysqli_connect("localhost", "root", "", "booking");

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $username = $_POST['username'];
        $password = $_POST['password'];

        // Prepare the SQL statement
        $query = "SELECT * FROM signup WHERE uname=? AND pword=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $username, $password); // Bind both username and password
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            $_SESSION['admin_id'] = $admin['id']; // Assuming 'id' is the primary key
            header("Location: admin_dashboard.php"); // Redirect to the admin dashboard
            exit();
        } else {
            echo "<script>alert('Invalid credentials.'); window.location.href='login.php';</script>";
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    }
    ?>
<body>
    <div class="container">
        <h2>Admin Login</h2>
        <form method="POST" action="">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn">Login</button>
        </form>
       
    </div>

    
</body>
</html>
